import requests as req
import datetime
import re
import pinyin
def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass
 
    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass
 
    return False
def shou1(name):
    return "".join([i[0] for i in pinyin.get(name, " ").split(" ")])
def shou2(name):
    if is_number(shou1(name))==True:
        return 0
    elif 65<=ord(shou1(name))&ord(shou1(name))<=90:
        return shou1(name)
    elif 97<=ord(shou1(name))&ord(shou1(name))<=122:
        return shou1(name)
    else:
        return 0
todaytime = str(datetime.datetime.now().year) +'-'+str(datetime.datetime.now().month)+'-'+'0'+str(datetime.datetime.now().day)
nothing = 0
done = 0
username = input('请输入账号用户名:')
userpasswd = input('请输入账号密码:')
logindata = {'username':username,'password':userpasswd,'usercookie':0,'action':'login','submit':'%26%23160%3B%B5%C7%26%23160%3B%26%23160%3B%C2%BC%26%23160%3B'}
login = req.post('https://www.wenku8.net/login.php',data=logindata)
login.encoding='gbk'
logintxt = login.text
if logintxt.find('登录成功')!= -1:
    print('登陆成功!即将开始爬取全部轻小说!')
    shouye = req.get('https://www.wenku8.net/modules/article/toplist.php?sort=postdate',cookies=login.cookies)
    shouye.encoding='gbk'
    shouyetxt = shouye.text
    n = re.findall(r'<div style="margin-top:5px;">(.*?).htm">',shouyetxt,re.DOTALL)
    n = re.findall(r'\d{4}',n[0])
    print('检测到wenku8共有'+n[0]+'本轻小说!')
    for i in range(1,int(n[0])+1):
        downlink=r'http://dl.wenku8.com/down.php?type=txt&id='+str(i)
        namelink=r'https://www.wenku8.net/book/'+str(i)+r'.htm'
        downtext = req.get(namelink,cookies=login.cookies)
        downtext.encoding='gbk'
        downtxt = downtext.text
        if downtxt.find(r'对不起，该文章不存在')==-1:            
            l = re.findall(r'content="(.*)小说,',downtxt)
            name = l[0]
            name = name.strip(r'?')
            print('正在下载第'+str(i)+'本轻小说:'+name+'!')
            print('剩余'+str(int(n[0])-i)+'本轻小说未下!')
            for a in name[:1]:
                shouzm = shou2(a)
            d = req.get(downlink,cookies=login.cookies)
            with open('./'+str(shouzm)+'/'+name+r'.txt', 'wb') as f:
                f.write(d.content)
                done = done +1
        else:
            print('第'+str(i)+'本轻小说:'+'不存在!')
            nothing = nothing +1
    print('全部下载完成!')
    print('实际下载%d本,有%d本小说不存在!'%done,nothing)   
else :
    print('登陆失败!请检查账号密码!')

