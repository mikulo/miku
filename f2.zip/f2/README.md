按照这个教程 在win上安装好python环境
https://567899.xyz/post/google_drive_folderclone/

把整个目录放到c盘根目录 

打开cmd 
运行

先运行
cd C:\folderclone-master-share
python masshare.py -d 目标目录

再运行

cd C:\folderclone-master-share
python multifolderclone.py -s 源目录 -d 目标目录

运行之前，分别替换上面的 源目录 和 目标目录 即可

其中源目录就是别人分享的目录id
目标目录:对应id
tmp
1-PyN8q3mqBznxRizmh7o1SOll-psPDBr
tmp1
1Il-aFGAXEyFAYMr6JgpnLytTB7kucZtO
tmp2
1bH2VIgoMJ6k4DvB2CLU5fsr0sKw7iiv1
tmp3
1W3SKIBAKDk8-FzAP6xTgAu2f4vay2ARe
tmp4
1vCLW3PbGSrw4kaSAhkpywGEzKnjcj59K
tmp5
1-OnhlTCZF5OF-gzJuxyCUZiN4i8dL6tC

看空目录就往里传即可

举个栗子

转移比较热门的 IMDB TOP250（1789.23G） 到 tmp目录， cmd 下运行这个：

cd C:\Multifolderclone-share
python multifolderclone.py -s 16ad_lUpTxcWXxeP_4ea17-BcEOC0jsqV -d 1-PyN8q3mqBznxRizmh7o1SOll-psPDBr

P.S. 自己用就行了，毕竟翻车了，就都没了，包括我😢